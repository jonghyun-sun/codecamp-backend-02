import mongoose from 'mongoose'

const PhoneSchema = new mongoose.schema({
    id:String,
    token:String,
    phone:String,
    isAuth:Boolean,
    v:Number


})

export const Phone = mongoose.model("Phone", boardSchema)