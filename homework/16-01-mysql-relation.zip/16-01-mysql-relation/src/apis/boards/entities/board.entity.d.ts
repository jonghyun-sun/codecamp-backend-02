export declare class Board {
    number: number;
    writer: string;
    title: string;
    contents: string;
}
