export declare class CreateBoardInput {
    writer: string;
    title: string;
    contents: string;
}
