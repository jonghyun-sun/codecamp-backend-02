export declare class BoardModule {
}
